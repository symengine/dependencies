#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\toom8h_mul.c"
