#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\dc_bdiv_qr.c"
