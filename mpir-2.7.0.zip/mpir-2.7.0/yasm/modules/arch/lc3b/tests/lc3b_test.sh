#! /bin/sh
${srcdir}/out_test.sh lc3b_test modules/arch/lc3b/tests "lc3b arch" "-a lc3b -f bin" ""
exit $?
